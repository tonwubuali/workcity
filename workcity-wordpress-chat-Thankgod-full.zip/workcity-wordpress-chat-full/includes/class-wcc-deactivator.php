<?php
// includes/class-wcc-deactivator.php
if (!defined('ABSPATH')) exit;

class WCC_Deactivator {
  public static function deactivate() {
    // No destructive actions on deactivate.
  }
}
